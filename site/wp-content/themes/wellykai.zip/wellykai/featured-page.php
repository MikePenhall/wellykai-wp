<?php
/**
 * The template for displaying the Featured page.
 * Template Name: Featured Page
 * 
 */

get_header(); ?>

		<div id="featured-page">
        	<h1><img src="/wp-content/themes/wellykai/images/FeaturedPosts.png" alt="About Us" height="45"/></h1>
			<div id="content" role="main">

				<?php the_post(); ?>

				<?php get_template_part( 'content', 'page' ); ?>

				<?php comments_template( '', true ); ?>

			</div><!-- #content -->
		</div><!-- #primary -->

<?php get_footer(); ?>